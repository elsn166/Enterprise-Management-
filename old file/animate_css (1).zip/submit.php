<?php
//error_reporting(0);
session_start();

   $Name =$_POST['form_name'];
   $Mobile_no =$_POST['form_phone'];
   $Email_id =$_POST['form_email'];
   $course=$_POST['form_msg'];
   $to="yuvaraj@rdegi.com";

$servername = "localhost";
$username = "vewon_website";
$password = "vewon@2021";
$dbname = "vewon_website";
global $Name;
global $Mobile_no;
global $Email_id;
global $course;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO vewon_website (username, mobile, mail, course)
VALUES ('$Name', '$Mobile_no', '$Email_id', '$course' )";

if ($conn->query($sql) === TRUE) {
//   echo "New record created successfully";
  $header = "From: arunkumar15ece022@gmail.com.com\r\n";
// $header .= 'Cc: mailto:yuvarajseenipandi29@gmail.com' . "\n";
$header.= "MIME-Version: 1.0\r\n";
$header.= "Content-Type: text/html; charset=ISO-8859-1\r\n";
$header.= "X-Priority: 1\r\n";
$subject="Enquiry Form Inventateq";
$message ='<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>WMS</title>
</head>
<body style="margin:0; padding:0">
<div style="width:600px; margin:0 auto; border-top:27px solid #FF3333; border-bottom:27px solid #FF3333; border-left:27px solid #F0F0F0; border-right:27px solid #F0F0F0; padding-bottom:10px;">
	
    
    <div class="detail">
    	<h1 style="font-size:16px; text-align:center; margin-top:30px; text-decoration:underline; color:#FF3333;"><strong>Enquiry Email from '.$Name.'</strong></h1>
    		<table rules="all" style="border-color: #666;" cellpadding="10">
    			<tr style="background: #eee;">
    				<td><strong>Name :</strong></td>
    				<td>'.$Name.'</td>
    			</tr>
          <tr>
    				<td><strong>Mobile No. :</strong></td>
    				<td >'.$Mobile_no.'</td>
    			</tr>
    			<tr style="background: #eee>
    				<td><strong>Email :</strong></td>
    				<td >'.$Email_id.'</td>
    			</tr>
    				<tr>
    				<td><strong>course :</strong></td>
    				<td >'.$course.'</td>
    			</tr>
    		</table><br>
    </div>
    
    
    
      </div>
		</div>
        <table>
        <tr>
	        <td height="27" align="center" valign="top" bgcolor="#f0f0f0">&nbsp;</td>
          </tr>
          </table>
     
</body>
</html>
';
$status = mail($to, $subject, $message, $header);
echo $status;
if($status)
{
  echo "<script>
    window.alert('Your Mail Sent Succesfully!');
    window.location.href='http://localhost:81/vewon/about_us.php';
    </script>";
} else {
   echo "<script>alert('Message could not be sent');</script>";
}
} 

// header("Location: http://innovateforyou.com/learning/contact.php"); 

$conn->close();
   

  
exit; 
?>