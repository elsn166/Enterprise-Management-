<?php
session_start(); 

$conn = mysqli_connect('localhost', 'root', '','vewon_register_form');



$username = $_POST['email'];  
$password = $_POST['password'];  
  

// CHANGING INTO THE SESSION VARIABLES
$_SESSION["email"] = $username;
$_SESSION["password"] = $password;



  //to prevent from mysqli injection  
  $username = stripcslashes($username);  
  $password = stripcslashes($password);  
  $username = mysqli_real_escape_string($conn, $username);  
  $password = mysqli_real_escape_string($conn, $password);  

  $sql = "SELECT * FROM login_form WHERE login_email = '$username' AND login_password = '$password'";  
  $result = mysqli_query($conn, $sql);  
  $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
  $count = mysqli_num_rows($result);  
    

  // IF EMAIL AND PASSWORD IS GOT, IT IS REDIRECT TO THE RESPECTIVE ADMIN-PANEL
  if($count == 1){ 
    echo "<script>window.location.assign('http://localhost:81/admin-panel/index.php')</script>";  
  }  
  else{  
    echo "<script>alert('Incorrect Email or Password.. Try Again')</script>";
    echo "<script>window.location.assign('login.php')</script>";  
  }     

// (-- MESSAGE --) NOW WE HAVE TO SET THE LOGIN SESSION WHEN THE USER CLICK A BACK BUTTON AFTER LOGOUT



$conn->close();



?>
